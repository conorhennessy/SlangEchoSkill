module.exports = {
	"fam":"Derived from the word family. Referring to people that are extremely close; as if  they are a family member."
	"mandem":""
}
//TODO: Add definitions for words here
